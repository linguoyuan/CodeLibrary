﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using LitJson;
using System;

public class Dispatcher
{
    private static Dictionary<Protocol, Action<JsonData>> _dic = new Dictionary<Protocol, Action<JsonData>>();

    private static void OnMessage(string s)
    {
        string temp = Xxtea.XXTEA.DecryptBase64StringToString(s, "223nndjk^&**75kKS5sjsd");
        //Debug.Log("OnMessage:" + temp);
        JsonData msg = JsonMapper.ToObject(Xxtea.XXTEA.DecryptBase64StringToString(s, "223nndjk^&**75kKS5sjsd"));
        //for test       
        //JsonData msg = JsonMapper.ToObject(s);       
        Protocol protocol = (Protocol)((int)msg["proto"]);
        JsonData data = msg["data"];
        if (_dic.ContainsKey(protocol))
        {
            Action<JsonData> func = _dic[protocol];
            if (func != null)
            {
                //每次收到一次消息后，更新一次心跳计算时间
                //NetWorkManager.Instance._lastPingTime = Time.realtimeSinceStartup;
                func(data);
            }
        }
    }

    /// <summary>
    /// 注册来自服务器的消息
    /// </summary>
    /// <param name="protocol">协议</param>
    /// <param name="listener">监听</param>
    public static void Register(Protocol protocol, Action<JsonData> listener)
    {
        if (_dic == null)
        {
            _dic = new Dictionary<Protocol, Action<JsonData>>();
        }
        _dic[protocol] = listener;
    }

    /// <summary>
    /// 注销来自服务器的消息
    /// </summary>
    /// <param name="protocol"></param>
    public static void UnRegister(Protocol protocol)
    {
        _dic.Remove(protocol);
    }
}


