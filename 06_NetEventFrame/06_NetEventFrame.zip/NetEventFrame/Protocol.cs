﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum Protocol
{
    CS_PING = 0,

    CS_LOGIN = 1,
    SC_LOGIN = 2,
}
