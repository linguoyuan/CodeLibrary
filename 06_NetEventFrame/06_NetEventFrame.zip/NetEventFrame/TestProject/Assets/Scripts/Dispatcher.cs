﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using LitJson;
using System;

public class Dispatcher
{
    private static Dictionary<Protocol, Action<JsonData>> _dic = new Dictionary<Protocol, Action<JsonData>>();

    private static WebSocketConnect _connect;
    public static WebSocketConnect Connect
    {
        get
        {
            return _connect;
        }
    }

    [RuntimeInitializeOnLoadMethod]
    private static void Initialize()
    {
        GameObject go = new GameObject("Net");
        UnityEngine.Object.DontDestroyOnLoad(go);

        _connect = go.AddComponent<WebSocketConnect>();

        Connect.OnMessage += OnMessage;
    }

    private static void OnMessage(String s)
    {
        string temp = Xxtea.XXTEA.DecryptBase64StringToString(s, "223nndjk^&**75kKS5sjsd");
        Debug.Log("OnMessage:" + s);
        JsonData msg = JsonMapper.ToObject(Xxtea.XXTEA.DecryptBase64StringToString(s, "223nndjk^&**75kKS5sjsd"));
        //for test       
        //JsonData msg = JsonMapper.ToObject(s);       
        Protocol protocol = (Protocol)((int)msg["proto"]);
        JsonData data = msg["data"];
        if (_dic.ContainsKey(protocol))
        {
            Action<JsonData> func = _dic[protocol];
            if (func != null)
            {
                //每次收到一次消息后，更新一次心跳计算时间
                //NetWorkManager.Instance._lastPingTime = Time.realtimeSinceStartup;
                func(data);
            }
        }
    }

    /// <summary>
    /// 注册来自服务器的消息
    /// </summary>
    /// <param name="protocol">协议</param>
    /// <param name="listener">监听</param>
    public static void Register(Protocol protocol, Action<JsonData> listener)
    {
        if (_dic == null)
        {
            _dic = new Dictionary<Protocol, Action<JsonData>>();
        }
        _dic[protocol] = listener;
    }

    /// <summary>
    /// 注销来自服务器的消息
    /// </summary>
    /// <param name="protocol"></param>
    public static void UnRegister(Protocol protocol)
    {
        _dic.Remove(protocol);
    }

    /// <summary>
    /// 向服务器发送请求
    /// </summary>
    /// <param name="protocol">请求的协议</param>
    /// <param name="info">请求的内容</param>
    public static void Send(Protocol protocol, JsonData info = null)
    {
        if (Connect != null)
        {
            if (!Connect.IsConnected()) return;
            //这里按照实际协议填写
            JsonData msg = new JsonData();
            msg["proto"] = (int)protocol;
            msg["random"] = UnityEngine.Random.Range(10000, 99999);
            msg["data"] = info;
            Connect.Send(Xxtea.XXTEA.EncryptToBase64String(msg.ToJson(), "223nndjk^&**75kKS5sjsd"));
        }
    }

    /// <summary>
    /// 暂停接收
    /// </summary>
    public static void Pause()
    {
        WebSocketConnect.LockMsg = true;
    }

    /// <summary>
    /// 恢复接收
    /// </summary>
    public static void Resume()
    {
        WebSocketConnect.LockMsg = false;
    }

    //关闭销毁链接
    public static void Dispose()
    {
        if (Connect != null)
        {
            Connect.Dispose();
            UnityEngine.Object.Destroy(Connect.gameObject);
        }
    }
}


