﻿using System;
using UnityEngine;
using System.Collections.Generic;
using WebSocketSharp;

/// <summary>
/// Socket连接
/// </summary>
public class WebSocketConnect : MonoBehaviour
{
    #region Internal Member

    protected WebSocket Ws;

    protected readonly Queue<string> StringMsgReceiveQueue = new Queue<string>();

    private bool _onConnect = false;
    private bool _onDisconnect = false;
    private bool _onError = false;
    private string _error;
    private int _disconnectCode;

    private bool _connected = false;

    //限制重连的间隔 10s重连一次
    float intervalTime = 50f;
    #endregion

    #region Event

    public event Action OnConnect;
    public event Action<string> OnMessage;
    public event Action<int> OnDisconnect;
    public event Action<string> OnError;

    public static bool LockMsg = false;

    #endregion

    #region API

    public void Update()
    {
        if (StringMsgReceiveQueue.Count > 0 && !LockMsg)
        {
            lock (StringMsgReceiveQueue)
            {
                while (StringMsgReceiveQueue.Count > 0 && !LockMsg)
                {
                    string msg = StringMsgReceiveQueue.Dequeue();
                    if (OnMessage != null)
                    {
                        OnMessage(msg);
                    }
                }
            }
        }

        if (_onConnect)
        {
            if (OnConnect != null)
            {
                OnConnect();
            }
            _onConnect = false;
        }

        intervalTime = intervalTime - 0.1f;
        if (intervalTime <= 0)
        {
            if (_onDisconnect)
            {               
                if (OnDisconnect != null)
                {
                    OnDisconnect(_disconnectCode);
                }               
                _onDisconnect = false;
            }
            intervalTime = 50f;
        }
        

        if (_onError)
        {
            if (OnError != null)
            {
                OnError(_error);
            }
            _onError = false;
        }
    }

    public bool IsConnected()
    {
        if (Ws == null)
            return false;
        return _connected;
    }

    public void Connect(string ip, int port)
    {
        if (Ws != null)
        {
            Ws.Close();
            Ws = null;
        }

        try
        {
            Debug.Log(Time.time +":ws://" + ip + ":" + port);
            Ws = new WebSocket("ws://" + ip + ":" + port);
            Ws.OnOpen += OnConnectInternal;
            Ws.OnClose += OnDisconnectInternal;
            Ws.OnMessage += OnMessageInternal;
            Ws.OnError += OnErrorInternal;
            Ws.WaitTime = TimeSpan.FromSeconds(2);
            //Ws.WaitTime = TimeSpan.FromSeconds(4);
            Ws.ConnectAsync();
        }
        catch (Exception e)
        {
            Debug.Log("连接异常");
            Debug.LogError(e);
        }
    }

    /// <summary>
    /// 发送消息
    /// </summary>
    /// <param name="msg"></param>
    public void Send(string msg)
    {
        if (!_connected) return;
        Ws.SendAsync(msg, SendCallBack);
    }

    private void SendCallBack(bool success)
    {
        if (!success)
        {
            Debug.LogError("数据发送失败");
        }
    }

    /// <summary>
    /// 无连接
    /// </summary>
    public void Disconnect()
    {
        if (Ws != null)
        {
            Ws.CloseAsync();
            Ws = null;
            _connected = false;
            //Debug.Log("关闭websocket");
        }
        else
        {
            Debug.Log("websocket = null");
            //by vic 2019.8.2 解决断线偶尔连不上问题
            if (OnDisconnect != null)
            {
                Debug.Log("30秒心跳判断，_onDisconnect:" + _onDisconnect);
                _onDisconnect = true;
            }
        }
    }

    public void Dispose()
    {
        if (Ws != null)
        {
            Ws.CloseAsync();
            Ws = null;
            _connected = false;
        }
    }

    #endregion

    #region Internal Message

    private void OnConnectInternal(object sender, EventArgs e)
    {
        _onConnect = true;
        _connected = true;
    }

    private void OnDisconnectInternal(object sender, CloseEventArgs e)
    {
        //Debug.LogWarning(e.Reason);
        //Debug.Log("OnDisconnectInternal, _onDisconnect = true");
        _disconnectCode = e.Code;
        _onDisconnect = true;
        _connected = false;
    }

    protected void OnMessageInternal(object sender, MessageEventArgs msg)
    {
        lock (StringMsgReceiveQueue)
        {
            StringMsgReceiveQueue.Enqueue(msg.Data);
        }
    }

    public void OnMessageInternalTest(string msg)
    {
        lock (StringMsgReceiveQueue)
        {
            StringMsgReceiveQueue.Enqueue(msg);
        }
    }

    private void OnErrorInternal(object sender, ErrorEventArgs error)
    {
        _onError = true;
        _error = error.Message;
        _connected = false;
    }

    #endregion
}
