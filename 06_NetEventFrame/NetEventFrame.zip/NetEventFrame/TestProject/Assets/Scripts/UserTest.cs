﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using LitJson;

public class UserTest : MonoBehaviour
{
    private WebSocketConnect WC;
    void Start()
    {
        Dispatcher.Register(Protocol.CS_LOGIN, MsgArrive);
        WC = GameObject.Find("Net").GetComponent<WebSocketConnect>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void OnClickBtn()
    {
        Debug.Log("click");
        string s = "  { \"proto\":1,   \"data\":\"我是一条json数据\"}  ";
        string k = "223nndjk^&**75kKS5sjsd";
        string temp = Xxtea.XXTEA.EncryptToBase64String(s, k);
        //string a = "\"Hello World\nHow are you\"";
        WC.OnMessageInternalTest(temp);
    }

    private void Fun1(string s)
    {
        Debug.Log("调用了Fun1 : " + s);
    }

    private void MsgArrive(JsonData s)
    {
        //Debug.Log("我是客户端， 收到：" + s);
        //Debug.Log("我是客户端， 收到：" + s.ToString());
        Debug.Log("我是客户端， 收到：" + s.ToJson());
    }
}
